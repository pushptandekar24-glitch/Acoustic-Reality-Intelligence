"""
Acoustic Reality Intelligence: An AI-Powered Environmental Audio Analysis and Synthetic Sound Assessment System.
Master Streamlit Application Orchestrator.
"""
import streamlit as st
from pathlib import Path

import config
from src.ui_helpers import apply_theme
from pages.overview import render_overview_page
from pages.audio_lab import render_audio_lab_page
from pages.sound_recognition_page import render_sound_recognition_page
from pages.authenticity_page import render_authenticity_page
from pages.segment_explorer import render_segment_explorer_page
from pages.comparison_page import render_comparison_page
from pages.evaluation_page import render_evaluation_page
from pages.reports_page import render_reports_page
from pages.about_page import render_about_page


# Streamlit Page Configuration
st.set_page_config(
    page_title=config.APP_NAME,
    page_icon="🎧",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Apply unified dark theme
apply_theme()

# Initialize session state variables
if "session_history" not in st.session_state:
    st.session_state.session_history = []
if "current_signal" not in st.session_state:
    st.session_state.current_signal = None
if "current_sr" not in st.session_state:
    st.session_state.current_sr = config.TARGET_SAMPLE_RATE
if "current_filename" not in st.session_state:
    st.session_state.current_filename = None
if "current_audio_bytes" not in st.session_state:
    st.session_state.current_audio_bytes = None
if "current_meta" not in st.session_state:
    st.session_state.current_meta = None
if "current_auth" not in st.session_state:
    st.session_state.current_auth = None
if "current_sound" not in st.session_state:
    st.session_state.current_sound = None
if "current_lab" not in st.session_state:
    st.session_state.current_lab = None
if "current_segments" not in st.session_state:
    st.session_state.current_segments = None


# Navigation List (as specified in Master Prompt Section 6)
NAV_PAGES = [
    "Overview",
    "Audio Laboratory",
    "Sound Recognition",
    "Authenticity Analysis",
    "Segment Explorer",
    "Compare Recordings",
    "Model Evaluation",
    "Reports",
    "About",
]

# Sidebar Brand & Navigation
with st.sidebar:
    st.markdown(
        """
        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
            <div style="width: 36px; height: 36px; border-radius: 9px; background: linear-gradient(135deg, #3878ff, #9561ff); display: grid; place-items: center; font-size: 18px;">
                🎧
            </div>
            <div>
                <div style="font-family: 'Space Grotesk', sans-serif; font-size: 1.05rem; font-weight: 700; color: #f3f6ff; line-height: 1.2;">
                    Acoustic Reality
                </div>
                <div style="font-size: 0.72rem; color: #31d2ff; font-weight: 600; letter-spacing: 0.05em; text-transform: uppercase;">
                    Intelligence v2.0
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

    st.markdown("<hr style='border-color: #263248; margin: 12px 0 16px;'/>", unsafe_allow_html=True)

    selected_page = st.radio(
        "Navigation",
        NAV_PAGES,
        index=0,
        label_visibility="collapsed"
    )

    st.markdown("<hr style='border-color: #263248; margin: 16px 0 12px;'/>", unsafe_allow_html=True)

    # Sidebar Active File Status Widget
    if st.session_state.current_filename:
        st.markdown(
            f"""
            <div style="background: rgba(16, 23, 37, 0.8); border: 1px solid #263248; border-radius: 9px; padding: 10px; font-size: 0.75rem;">
                <div style="color: #9aa9c1; text-transform: uppercase; font-size: 0.65rem; margin-bottom: 2px;">Active Track</div>
                <strong style="color: #f3f6ff; word-break: break-all;">{st.session_state.current_filename}</strong>
                <div style="color: #31d2ff; margin-top: 4px;">{st.session_state.current_meta.get('duration_seconds', 0):.2f}s · 16 kHz Mono</div>
            </div>
            """,
            unsafe_allow_html=True
        )
        if st.button("Clear Active Audio", use_container_width=True):
            st.session_state.current_signal = None
            st.session_state.current_filename = None
            st.session_state.current_audio_bytes = None
            st.session_state.current_meta = None
            st.session_state.current_auth = None
            st.session_state.current_sound = None
            st.session_state.current_lab = None
            st.session_state.current_segments = None
            st.rerun()
    else:
        st.markdown(
            """
            <div style="background: rgba(16, 23, 37, 0.5); border: 1px dashed #263248; border-radius: 9px; padding: 10px; font-size: 0.75rem; text-align: center; color: #9aa9c1;">
                No audio loaded<br/><span style="font-size: 0.68rem; color: #62728c;">Upload on Overview</span>
            </div>
            """,
            unsafe_allow_html=True
        )

    # Verification Integrity Tag
    st.markdown(
        """
        <div style="margin-top: 20px; font-size: 0.68rem; color: #6b7c96; text-align: center;">
            SVM SHA-256 Verified<br/>
            b6d965c31ceba6a6...
        </div>
        """,
        unsafe_allow_html=True
    )


# Route to Selected Page
if selected_page == "Overview":
    render_overview_page()
elif selected_page == "Audio Laboratory":
    render_audio_lab_page()
elif selected_page == "Sound Recognition":
    render_sound_recognition_page()
elif selected_page == "Authenticity Analysis":
    render_authenticity_page()
elif selected_page == "Segment Explorer":
    render_segment_explorer_page()
elif selected_page == "Compare Recordings":
    render_comparison_page()
elif selected_page == "Model Evaluation":
    render_evaluation_page()
elif selected_page == "Reports":
    render_reports_page()
elif selected_page == "About":
    render_about_page()
