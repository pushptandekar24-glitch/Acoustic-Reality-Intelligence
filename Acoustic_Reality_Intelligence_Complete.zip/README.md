# Acoustic Reality Intelligence (v2.0)
### *An AI-Powered Environmental Audio Analysis and Synthetic Sound Assessment System*

---

## 1. Executive Summary & Problem Statement

With the rapid emergence of generative audio architectures (e.g., AudioLDM, ElevenLabs, Diffusion and GAN-based audio synthesis), synthetic audio generation has expanded far beyond speech deepfakes into **environmental audio and acoustic scenes**. Generative soundscapes—such as artificial rain, sirens, gunshots, crowd commotion, and vehicle engines—are increasingly deployed in misinformation campaigns, insurance fraud, and falsified acoustic surveillance.

Standard audio classification tools typically focus only on detecting speech deepfakes or categorizing sound events, failing to provide comprehensive acoustic intelligence. **Acoustic Reality Intelligence** is a multi-dimensional platform combining **Digital Signal Processing (DSP)**, **Psychoacoustic Feature Extraction**, **Environmental Audio Scene Classification**, and **Machine-Learning Synthetic Audio Assessment** into a unified, interactive laboratory dashboard.

---

## 2. Motivation & Objectives

1. **Multi-Domain Acoustic Forensics:** Move beyond simplistic real-vs-synthetic binary outputs by providing physical frequency decompositions, Mel spectrograms, and temporal energy dynamics.
2. **Strict Decoupling of Sound Events and Authenticity:** Disentangle *what* sound event is present (e.g., rain, bird chirping, sirens) from *how* that sound was generated. The presence of identifiable natural sounds is never confused with proof of authenticity.
3. **Rigorous Cryptographic Model Verification:** Implement strict SHA-256 fingerprint verification and ground-truth metadata integrity checks to prevent silent model substitution or inverted class mappings.
4. **Temporal Discontinuity Exploration:** Partition recordings into overlapping time windows to detect localized splice edits, abrupt spectral shifts, and energy anomalies.
5. **Reproducible Academic Evaluation:** Provide verified benchmark baseline replication from the original experimental test split (83.75% accuracy) alongside live ground-truth evaluation tools.
6. **Automated Forensic Documentation:** Generate printable, multi-section PDF technical reports complete with embedded spectral figures and structured CSV feature tables.

---

## 3. System Architecture

```text
Acoustic_Reality_Intelligence_V2/
│
├── app.py                             # Master Streamlit dashboard orchestrator
├── config.py                          # Global configuration, constants, and theme palette
├── requirements.txt                   # Dependency specifications
├── README.md                          # Project documentation and user guide
├── .gitignore                         # Version control ignore rules
│
├── models/
│   ├── acoustic_model.joblib          # Trained SVM pipeline (StandardScaler + SVC RBF)
│   └── acoustic_model_metadata.json   # Verified metadata (SHA-256, class mapping, hyperparameters)
│
├── src/
│   ├── __init__.py
│   ├── audio_processing.py            # Decoding, resampling (16 kHz mono), validation, metadata
│   ├── acoustic_features.py           # 26-MFCC extraction & comprehensive DSP laboratory features
│   ├── synthetic_detection.py         # SHA-256 verified SVM inference & headline generation
│   ├── sound_recognition.py           # Environmental audio event classification (spectral signatures)
│   ├── segment_analysis.py            # Windowed segmentation & Z-score acoustic anomaly exploration
│   ├── recording_comparison.py        # Side-by-side comparison, Cosine similarity, & DTW cost
│   ├── model_evaluation.py            # Confusion matrix, accuracy, precision, recall, F1, baseline
│   ├── report_generator.py            # Multi-section PDF compilation (ReportLab) & CSV export
│   └── ui_helpers.py                  # Dark-theme styling, metric cards, and plot helpers
│
├── pages/
│   ├── overview.py                    # Session metrics, file uploader, sample loader, recent feed
│   ├── audio_lab.py                   # Waveforms, STFT, Mel spectrograms, MFCCs, DSP curves
│   ├── sound_recognition_page.py      # Environmental sound rankings, physical descriptors
│   ├── authenticity_page.py           # Verified headline (REAL vs AI-GENERATED), probabilities
│   ├── segment_explorer.py            # Windowed timeline, anomaly flags, segment-level SVM
│   ├── comparison_page.py             # Side-by-side comparative DSP, similarity percentage, DTW
│   ├── evaluation_page.py             # Replicated baseline confusion matrix & custom ground-truth testing
│   ├── reports_page.py                # Formal PDF download & 26-MFCC CSV export
│   └── about_page.py                  # DSP math, model provenance, defense & viva guide
│
├── sample_audio/                      # Built-in demonstration audio samples
│   ├── sample_rain_thunder.wav
│   ├── sample_birds_insects.wav
│   └── sample_siren_alarm.wav
│
├── tests/                             # Comprehensive automated pytest suite (22 unit tests)
│   ├── test_audio_processing.py
│   ├── test_class_mapping.py
│   ├── test_features.py
│   ├── test_evaluation.py
│   ├── test_report_generator.py
│   └── test_segment_and_comparison.py
│
└── existing_assets/                   # Pristine backups of original model and assets
```

---

## 4. Digital Signal Processing & Machine Learning Workflow

```
[Uploaded Audio (WAV/MP3/FLAC/OGG/M4A)]
                   │
                   ▼
       [Audio Decoding & Validation]
    (Check size, header, non-empty, finite)
                   │
                   ▼
     [Resampling: 16 kHz Mono Standard]
                   │
        ┌──────────┴──────────┐
        ▼                     ▼
[Acoustic Laboratory]   [Feature Extraction Pipeline]
- Waveform              - STFT (n_fft=2048, hop=512)
- STFT Spectrogram (dB) - 13 MFCC Coefficients
- Mel Spectrogram (dB)  - Mean (13) + Std Dev (13)
- RMS, ZCR, Centroid    - 26-Dimensional Feature Vector
- Bandwidth, Flatness                 │
        │                             ▼
        │                 [Cryptographic Verification]
        │                 - SHA-256 Checksum Match
        │                 - Verified Class Metadata
        │                             │
        │                             ▼
        │                 [StandardScaler Normalization]
        │                             │
        │                             ▼
        │                 [Support Vector Classifier (RBF)]
        │                             │
        ▼                             ▼
[Environmental Recognition]  [Synthetic Audio Assessment]
(Physical DSP Scene Engine)  (Verified Dynamic Headline:
                             - Your audio appears to be REAL
                             - Your audio appears to be AI-GENERATED)
```

### Verified Class Mapping
Inspected directly from the original training notebook (`Acoustic_Reality_Intelligence.ipynb`):
- `y.append(1 if label == "fake" else 0)`
- `classification_report(labels=[0, 1], target_names=["Real", "AI-generated"])`

Therefore:
- **Numeric Class 0 = Real Audio** $\rightarrow$ Headline: `Your audio appears to be REAL` (Green `#2bd49a`)
- **Numeric Class 1 = AI-Generated Audio** $\rightarrow$ Headline: `Your audio appears to be AI-GENERATED` (Pink/Magenta `#ff6d8b`)

### Cryptographic Fingerprint
The model file is verified against its reference SHA-256 fingerprint before inference:
```text
b6d965c31ceba6a6be2483af2e378dead36f59a44ea97f5c3b3cf6f5a8160f91
```

---

## 5. Module Breakdown

### Module A — Overview Dashboard
- Interactive activity statistics: Session recordings evaluated, latest model prediction, latest acoustic event.
- Live recent analyses table tracked continuously in session memory.
- Quick audio uploader supporting drag-and-drop.
- Built-in demonstration audio buttons (`Rain & Thunder`, `Birds & Insects`, `Siren & Alarm`) for instant testing.
- Clean empty states when no audio has been uploaded yet.

### Module B — Audio Upload & Processing
- Secure decoding via Librosa and SoundFile.
- Format validation for WAV, MP3, FLAC, OGG, and M4A.
- Comprehensive metadata extraction: duration, sample rate, channels, bit depth, peak amplitude, RMS energy, and clipping detection.
- Fail-safe handling for corrupted, empty, or silent audio clips.

### Module C — Audio Laboratory
- High-resolution dark-themed visual displays:
  - Amplitude Waveform with time calibration.
  - Short-Time Fourier Transform (STFT) magnitude spectrogram (dB).
  - 128-band Mel-frequency spectrogram (dB).
  - 13-coefficient MFCC heatmap across time frames.
  - Interactive temporal curves: RMS Energy, Spectral Centroid, Zero-Crossing Rate.
- Comprehensive acoustic statistics table (mean, std dev, min, max, median, crest factor, dynamic range in dB).
- Clear technical explanation: acoustic metrics quantify physical wave attributes and do not constitute forensic proof of authenticity on their own.

### Module D — Environmental Sound Recognition
- Real, mathematically grounded acoustic event recognition based on physical psychoacoustics:
  - Spectral centroid (timbral brightness).
  - Spectral flatness (broadband noise vs. tonal harmonicity).
  - Sub-band energy ratios (Low $<500$ Hz, Mid $500-3000$ Hz, High $>3000$ Hz).
  - Envelope burstiness and modulation index.
- Standard environmental taxonomy:
  - *Rain & Thunder*
  - *Birds & Insects*
  - *Traffic & Vehicles*
  - *Sirens & Alarms*
  - *Human Speech & Crowd*
  - *Wind & Natural Flow*
  - *Animals & Wildlife*
  - *Mechanical & Industrial*
- Ranked likelihood bar charts and physical descriptor inspection.
- Decoupling guarantee: Recognizes what sound event is present, never confusing recognizable sound with authenticity.

### Module E — Synthetic Audio Assessment
- Evaluates the 26-MFCC feature vector through the verified `StandardScaler + SVC(kernel='rbf', probability=True)` pipeline.
- Prominently displays the required single headline:
  - `Your audio appears to be REAL` in vibrant green.
  - `Your audio appears to be AI-GENERATED` in vibrant pink/magenta.
- Displays probability estimates as statistical model estimates rather than calibrated guarantees.
- Integrity details: SHA-256 verification status, kernel type, and input dimensions.
- Technical disclaimer clarifying that the model provides an experimental estimate.

### Module F — Segment Explorer & Anomaly Detection
- Splits audio into configurable sliding windows (0.5s to 5.0s, with 0% to 75% overlap).
- Tracks temporal trajectories of RMS energy, Spectral Centroid, and ZCR.
- Z-score based anomaly detection: flags sharp energy step-changes and abrupt spectral boundary transitions.
- Evaluates the SVM classifier independently across individual segments to display a localized authenticity timeline.
- Explains that acoustic anomalies are points for investigation (ambient transients, mic handling) rather than proof of tampering.

### Module G — Compare Two Recordings
- Dual upload slots for Recording A (Reference) and Recording B (Comparison).
- Side-by-side waveforms and spectrograms on synchronized axes.
- Quantitative similarity and distance metrics:
  - Cosine Similarity on 26-MFCC feature vectors ($0-100\%$).
  - Cosine Distance in feature Hilbert space.
  - Normalized Dynamic Time Warping (DTW) sequence alignment cost.
  - Absolute acoustic delta table (Duration, RMS, Centroid, ZCR).
- Documentation clarifying that high acoustic similarity indicates comparable timbre, not identical provenance.

### Module H — Model Evaluation Laboratory
- Replicated Benchmark Baseline from the original training notebook:
  - Total test samples: $80$ ($40$ Real, $40$ AI-generated).
  - Test accuracy: $83.75\%$.
  - Precision / Recall / F1-Score: $0.84$.
  - Replicated confusion matrix ($34$ TN, $6$ FP, $7$ FN, $33$ TP).
- Interactive Custom Ground-Truth Testing: upload a labeled CSV (`y_true` column) to generate live confusion matrices and classification reports.
- One-click CSV export of detailed sample-level evaluation results.

### Module I — Reports & Exports
- Downloadable technical PDF report compiled using ReportLab:
  - Audio metadata and processing timestamp.
  - Authenticity headline, model prediction, and probability breakdown.
  - Environmental sound recognition rankings and primary detected event.
  - Complete Acoustic Laboratory DSP metrics table.
  - Embedded high-resolution PNG plots of waveform and STFT spectrogram.
  - Segment analysis summary and flagged anomalies.
  - Cryptographic model SHA-256 fingerprint.
  - Legal, technical, and interpretation disclaimers.
- Structured CSV export of 26 MFCC numerical features matching the model input format.

---

## 6. Installation & Launch Instructions (Windows PowerShell)

### Prerequisites
- Windows 10 or 11
- Python 3.10+ (tested on Python 3.10, 3.11, 3.12, 3.15)
- Standard audio drivers

### Step 1: Clone or Extract Workspace
Open Windows PowerShell and navigate to the project directory:
```powershell
cd C:\Users\pushp\Desktop\Acoustic_Reality_Intelligence_V2
```

### Step 2: (Optional) Create and Activate Virtual Environment
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### Step 3: Install Required Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Run Automated Verification Tests
```powershell
python -m pytest tests/ -v
```
*All 22 unit and integration tests should pass.*

### Step 5: Launch the Streamlit Dashboard
```powershell
streamlit run app.py
```
The application will launch automatically in your browser at `http://localhost:8501`.

---

## 7. Model Evaluation Results

### Benchmark Baseline (Original Experimental Notebook)
The classifier was trained on an 80-sample held-out random test split (`random_state=42`) using 26 MFCC statistical features:

| Metric | Measured Baseline |
| :--- | :--- |
| **Test Accuracy** | **83.75%** |
| **Macro Precision** | **0.84** |
| **Macro Recall** | **0.84** |
| **Macro F1-Score** | **0.84** |
| **Real (Class 0) Precision / Recall** | **0.83 / 0.85** |
| **AI-Generated (Class 1) Precision / Recall** | **0.85 / 0.83** |
| **Total Test Samples** | **80 (40 Real, 40 AI)** |

#### Baseline Confusion Matrix
```text
                     Predicted Real (0)    Predicted AI (1)
True Real (0)                34                   6        (TN = 34, FP = 6)
True AI-Generated (1)         7                  33        (FN = 7,  TP = 33)
```

*Note: This baseline reflects performance on the original experimental dataset. It serves as an empirical benchmark and is not a guarantee of identical accuracy on unconstrained, heavily compressed real-world audio.*

---

## 8. Step-by-Step Demonstration Workflow

Follow these steps for an interactive academic demonstration:

1. **Launch the App:** Run `streamlit run app.py` and open the dashboard.
2. **Explore Overview & Demo Audio:**
   - In the Overview page, click the **🌧 Rain & Thunder** demonstration button.
   - Observe instant decoding, audio player loading, and session tracking metrics updating in real time.
3. **Inspect the Audio Laboratory:**
   - Navigate to **Audio Laboratory** in the sidebar.
   - Inspect the dual Waveform and Spectrogram visualization.
   - Switch tabs to inspect the 128-band Mel Spectrogram and the 13 MFCC coefficient heatmap.
   - Review the detailed acoustic summary statistics (RMS Energy, Centroid, Dynamic Range).
4. **Identify Environmental Sound Events:**
   - Navigate to **Sound Recognition**.
   - Review the primary detected event (e.g. *Rain & Thunder* at high likelihood) and the physical DSP descriptors (high spectral flatness, low-frequency rumble).
   - Point out the technical disclaimer stating that identifying rain does not prove authenticity.
5. **Verify Authenticity Assessment:**
   - Navigate to **Authenticity Analysis**.
   - Observe the prominent verified headline: `Your audio appears to be REAL` or `Your audio appears to be AI-GENERATED`.
   - Inspect the model probability estimate bars and the verified SHA-256 fingerprint badge.
6. **Analyze Temporal Segments:**
   - Navigate to **Segment Explorer**.
   - Observe the recording divided into 2.0-second sliding windows.
   - Review the temporal trajectory chart (RMS, Centroid, and segment-level AI probability).
   - Point out any acoustic anomalies flagged by the Z-score boundary transition detector.
7. **Perform Comparative Evaluation:**
   - Navigate to **Compare Recordings**.
   - Notice that the active track is automatically populated as Track A. Upload or select a different track for Track B.
   - Review the MFCC Cosine Similarity percentage, DTW sequence cost, and side-by-side synchronized spectrograms.
8. **Inspect Model Evaluation:**
   - Navigate to **Model Evaluation**.
   - Review the replicated 80-sample benchmark confusion matrix ($83.75\%$ accuracy).
9. **Export PDF & CSV Reports:**
   - Navigate to **Reports**.
   - Click **Download PDF Technical Report** to generate and open the formal, printable forensic document complete with embedded spectrogram plots.
   - Click **Download Structured Features (CSV)** to inspect the 26 numerical MFCC features.

---

## 9. Academic Project Identity & License

- **Project:** Acoustic Reality Intelligence (ARI v2.0)
- **Institution:** College Mini-Project / Final Year Engineering Demonstration
- **Specializations:** Digital Signal Processing (DSP), Machine Learning Forensics, Audio Information Retrieval (AIR)
- **License:** MIT Open Source Academic License
